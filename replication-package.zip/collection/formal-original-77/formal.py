"""Reference-free formal coordinator using the proven single-request launcher."""
import argparse,hashlib,importlib.util,json,subprocess,sys,zipfile
from datetime import datetime,timezone
from pathlib import Path
from run_one import parse_logs
from validate_output import validate_response
ROOT=Path(__file__).resolve().parent
FILES=('launch.json','answer.txt','events.jsonl','stderr.txt','submitted.txt','preflight.txt')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def stamp():return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
def save(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(o,f,indent=2)
def verify():
    for name,h in read(ROOT/'manifest.sha256.json').items():
        p=(ROOT/name).resolve()
        if not p.is_relative_to(ROOT) or sha(p)!=h:raise SystemExit('Kit changed: '+name)
def tasks():return {t['task_id']:t for t in map(json.loads,(ROOT/'requests.jsonl').read_text(encoding='utf-8').splitlines())}
def jobs():return read(ROOT/'schedule.json')['runs']
def call(args):
    r=subprocess.run([str(x) for x in args],shell=False)
    if r.returncode:raise SystemExit('Stopped; preserve logs. No automatic retry. Exit '+str(r.returncode))
def launch(state,prompt,out,dry=False):
    if sha(Path(state['codex_path']))!=state['codex_sha256']:raise SystemExit('Codex executable changed since reviewed smoke')
    args=[sys.executable,'-B',ROOT/'run_one.py','--product','codex','--executable',state['codex_path'],'--model','gpt-6-astra','--effort','medium','--prompt',prompt,'--out',out,'--config',ROOT/'run-config.json']
    if dry:args+=['--dry-run']
    call(args)
def inspect(task,folder,prompt):
    if not all((folder/n).is_file() for n in FILES):raise SystemExit('Incomplete attempt; preserve and inspect '+str(folder))
    m=read(folder/'launch.json');argv=m['argv'];disabled={argv[i+1] for i,x in enumerate(argv[:-1]) if x=='--disable'}
    raw=(folder/'events.jsonl').read_text(encoding='utf-8');audit=parse_logs('codex',raw,disabled)
    if m.get('returncode')!=0 or audit['review_flags'] or m.get('review_flags'):raise SystemExit('Control/runtime review required: '+str(folder))
    required=['--ephemeral','--ignore-user-config','--sandbox','read-only','web_search="disabled"','memories.use_memories=false','project_doc_max_bytes=0','apps._default.enabled=false','model_reasoning_effort="medium"']
    if not all(x in argv for x in required) or not {'shell_tool','view_image','code_mode_host','apps','plugins','memories'}<=disabled:raise SystemExit('Required controls missing')
    if m.get('requested_model')!='gpt-6-astra' or m.get('requested_effort')!='medium' or m.get('mode')!='single live request':raise SystemExit('Model/effort/run mismatch')
    if m.get('effective_config_sha256')!=sha(ROOT/'run-config.json'):raise SystemExit('Config mismatch')
    if sha(prompt)!=sha(folder/'submitted.txt') or m.get('submitted_prompt_sha256')!=sha(prompt):raise SystemExit('Prompt mismatch')
    answer=(folder/'answer.txt').read_text(encoding='utf-8')
    if not any(e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message' and e['item'].get('text','').strip()==answer.strip() for e in map(json.loads,raw.splitlines()) if e):raise SystemExit('Final answer/event mismatch')
    _,rows,errors=validate_response(task,answer)
    return {'valid_rows':len(rows),'expected_rows':len(task['requested_rows']),'format_errors':errors,'control_notices':audit['control_notices'],'files':{n:sha(folder/n) for n in FILES},'reported_model':audit['reported_models'],'reported_usage':audit['reported_usage'],'human_control_review':'PENDING'}
def check_smoke(setup):
    oldroot=setup.resolve().parent;baseline=read(ROOT/'smoke-baseline.json')
    if sha(oldroot/'manifest.sha256.json')!=baseline['manifest_sha256']:raise SystemExit('Smoke kit differs from expected reviewed version')
    for n,h in read(oldroot/'manifest.sha256.json').items():
        p=(oldroot/n).resolve()
        if not p.is_relative_to(oldroot) or sha(p)!=h:raise SystemExit('Smoke kit changed: '+n)
    state=read(setup)
    if not state.get('isolation_attested'):raise SystemExit('Smoke isolation attestation missing')
    if sha(Path(state['codex_path']))!=state['codex_sha256']:raise SystemExit('Codex changed after smoke setup')
    # Execute only our already hash-verified smoke inspection functions, not an
    # arbitrary caller-supplied module. This reads results; it launches no model.
    spec=importlib.util.spec_from_file_location('_ordinal_reviewed_smoke',oldroot/'smoke.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    inspected=[module.inspect(t,oldroot/'results'/t['task_id']/'attempt0') for t in module.tasks()]
    if len(inspected)!=8 or any(x['format_errors'] for x in inspected):raise SystemExit('All eight smoke answers must pass schema and log checks')
    return state,{'smoke_setup_sha256':sha(setup),'smoke_manifest_sha256':baseline['manifest_sha256'],'tasks':inspected,'technical_checks_pass':True}
def render(messages):return '\n\n'.join('['+m['role'].upper()+' INSTRUCTIONS]\n'+m['content'] for m in messages)+'\n'
def repair_prompt(task,folder,errors):
    messages=task['messages']+[{'role':'assistant','content':(folder/'attempt0/answer.txt').read_text(encoding='utf-8')},{'role':'user','content':'Repair only the JSON/output-contract errors in your own preceding answer. Preserve valid probability judgments when possible. Use the original task and supplied evidence only. Return the exact original schema and all requested rows, with no Markdown. Validation errors: '+json.dumps(errors)}]
    expected=render(messages);p=folder/'repair.txt'
    if p.exists() and p.read_text(encoding='utf-8')!=expected:raise SystemExit('Repair prompt changed')
    if not p.exists():
        with p.open('x',encoding='utf-8') as f:f.write(expected)
        save(folder/'repair-record.json',{'kind':'one bounded fresh-session format repair','original_messages_sha256':task['messages_sha256'],'errors':errors,'prompt_sha256':sha(p)})
    return p
def inspect_receipt(job,task,base):
    folder=base/job['run_id'];record=read(folder/'completed.json')
    if record['run_id']!=job['run_id'] or record['task_id']!=job['task_id'] or record['repetition']!=job['repetition']:raise SystemExit('Receipt identity mismatch')
    for attempt,expected in record['attempts'].items():
        if attempt not in ('attempt0','attempt1'):raise SystemExit('Unexpected attempt')
        prompt=ROOT/'prepared'/f"{task['task_id']}.txt" if attempt=='attempt0' else folder/'repair.txt'
        if attempt=='attempt1':repair_prompt(task,folder,record['attempts']['attempt0']['format_errors'])
        if inspect(task,folder/attempt,prompt)!=expected:raise SystemExit('Completed records changed: '+str(folder))
    return record
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('phase',choices=['prepare','freeze','run','check','export']);p.add_argument('--smoke-setup',type=Path)
    p.add_argument('--reviewer');p.add_argument('--smoke-reviewed',action='store_true');p.add_argument('--replicate',type=int,choices=range(0,6),default=0);p.add_argument('--limit',type=int,default=40)
    a=p.parse_args();verify();statefile=ROOT/'formal-session.json';base=ROOT/'results'
    if a.phase=='prepare':
        if statefile.exists():print('Already prepared; existing records preserved. Continue with Freeze/Run.');return
        if not a.smoke_setup:raise SystemExit('--smoke-setup must point to the current ORD-SMOKE-1 local-session.json')
        old,review=check_smoke(a.smoke_setup)
        state={'python_path':sys.executable,'codex_path':old['codex_path'],'codex_sha256':old['codex_sha256'],'client_version':old['client_version'],'manifest_sha256':sha(ROOT/'manifest.sha256.json'),'smoke_setup':str(a.smoke_setup.resolve()),'created_utc':now()}
        out=ROOT/'preflight';prompt=ROOT/'prepared'/f"{jobs()[0]['task_id']}.txt"
        if not out.exists():launch(state,prompt,out,True)
        m=read(out/'launch.json')
        if m.get('mode')!='dry-run' or m.get('requested_effort')!='medium' or m.get('effective_config_sha256')!=sha(ROOT/'run-config.json'):raise SystemExit('Existing preflight mismatch')
        save(ROOT/'smoke-review.json',review);save(statefile,state)
        print('PREPARED: eight smoke results verified. Existing Python/Codex reused; no model called.');return
    if not statefile.is_file():raise SystemExit('Run Prepare with the current smoke local-session.json first')
    state=read(statefile)
    if state['manifest_sha256']!=sha(ROOT/'manifest.sha256.json'):raise SystemExit('Kit differs from setup')
    frozen=ROOT/'freeze.json'
    if a.phase=='freeze':
        if frozen.exists():print('Already frozen; records preserved.');return
        if not a.reviewer or not a.smoke_reviewed:raise SystemExit('After reviewing smoke answers/logs, provide --reviewer and --smoke-reviewed')
        _,review=check_smoke(Path(state['smoke_setup']))
        if review!=read(ROOT/'smoke-review.json'):raise SystemExit('Smoke records changed since Prepare')
        save(frozen,{'created_utc':now(),'reviewer':a.reviewer,'human_smoke_review':True,'manifest_sha256':sha(ROOT/'manifest.sha256.json'),'config_sha256':sha(ROOT/'run-config.json'),'smoke_review_sha256':sha(ROOT/'smoke-review.json'),'planned_initial_requests':read(ROOT/'run-config.json')['planned_initial_requests'],'requested_model':'gpt-6-astra','requested_effort':'medium','serving_identity_independently_verified':False,'isolation_basis':'Reuse operator isolation attestation from reviewed smoke; no pretraining decontamination claim'})
        print('FROZEN; no model called. Run a bounded chunk, then continue the same schedule.');return
    if not frozen.is_file():raise SystemExit('Formal collection is not frozen. Review smoke results, then use Freeze.')
    lock=read(frozen)
    if lock['manifest_sha256']!=sha(ROOT/'manifest.sha256.json') or lock['config_sha256']!=sha(ROOT/'run-config.json') or lock['smoke_review_sha256']!=sha(ROOT/'smoke-review.json'):raise SystemExit('Frozen records changed')
    tm=tasks();schedule=jobs()
    if a.phase=='export':
        dest=ROOT/('ordinal-formal-results-'+stamp()+'.zip')
        with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
            for name in ['formal-session.json','freeze.json','smoke-review.json','schedule.json','run-config.json','manifest.sha256.json']:z.write(ROOT/name,name)
            for j in schedule:
                for suffix in ['completed.json','repair.txt','repair-record.json']+[f'attempt{i}/{n}' for i in (0,1) for n in FILES]:
                    f=base/j['run_id']/suffix
                    if f.is_file() and not f.is_symlink() and f.resolve().is_relative_to(base.resolve()):z.write(f,'results/'+j['run_id']+'/'+suffix)
        print('Exported (may be partial): '+str(dest));return
    chosen=[j for j in schedule if a.replicate in (0,j['repetition'])]
    if a.phase=='check':
        done=[];started=[]
        for j in chosen:
            folder=base/j['run_id']
            if (folder/'completed.json').is_file():done.append(inspect_receipt(j,tm[j['task_id']],base))
            elif folder.exists():started.append(j['run_id'])
        report={'expected':len(chosen),'completed':len(done),'unfinished_attempts':started,'fallback_nodes':sum(r['format_status']=='fallback_required' for r in done),'human_control_review':'PENDING','accuracy_scored_here':False}
        save(ROOT/('progress-'+stamp()+'.json'),report);print(json.dumps(report,indent=2));return
    if a.limit<1:raise SystemExit('--limit must be positive; default 40 new node trials per command')
    count=0
    for j in chosen:
        task=tm[j['task_id']];folder=base/j['run_id'];prompt=ROOT/'prepared'/f"{task['task_id']}.txt"
        if (folder/'completed.json').exists():inspect_receipt(j,task,base);continue
        print(f"[{count+1}/{a.limit}] {j['run_id']}",flush=True)
        first=folder/'attempt0'
        if not first.exists():launch(state,prompt,first)
        r0=inspect(task,first,prompt);attempts={'attempt0':r0}
        if r0['format_errors']:
            repair=repair_prompt(task,folder,r0['format_errors']);second=folder/'attempt1'
            if not second.exists():launch(state,repair,second)
            attempts['attempt1']=inspect(task,second,repair)
        final=list(attempts.values())[-1]
        save(folder/'completed.json',{'run_id':j['run_id'],'task_id':j['task_id'],'repetition':j['repetition'],'attempts':attempts,'format_status':'fallback_required' if final['format_errors'] else 'valid','human_control_review':'PENDING','completed_utc':now()})
        count+=1
        if count>=a.limit:break
    print(f'Chunk complete: {count} newly completed trials. Repeat Run to continue; completed trials are verified and skipped.')
if __name__=='__main__':main()
